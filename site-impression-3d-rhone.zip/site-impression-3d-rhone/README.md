# Site vitrine — Atelier 3D Rhône

## Aperçu
Site vitrine responsive en une page, en français, pour une activité d'impression 3D dans le Rhône.

## Mise en ligne : à personnaliser avant publication
1. Dans `index.html`, remplacez `ATELIER 3D RHÔNE` par le nom réel si nécessaire.
2. Remplacez `VOTRE-EMAIL@exemple.fr` par l'adresse e-mail qui recevra les demandes.
3. Ajoutez vos coordonnées réelles, votre commune, vos horaires et vos conditions de livraison.
4. Vérifiez les textes (matériaux, technologies, délais, capacités) pour qu'ils correspondent exactement à votre activité.

Le formulaire utilise `mailto` : il prépare un e-mail dans le logiciel de messagerie du visiteur. Pour recevoir les demandes directement depuis le site, il faudra connecter un service de formulaire ou un backend.

## Publication
Déposez `index.html` sur un hébergement web statique (par exemple votre hébergeur actuel, Netlify ou GitHub Pages). Aucun framework ni installation n'est nécessaire.
